import requests
import json
from config import DefaultConfig

CONFIG = DefaultConfig()

def process_text(text):
    # url = "https://prod-94.eastus.logic.azure.com:443/workflows/662e0abb72fa46b39302350e08041a50/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=X2sxDEqTt_yE1JMl033mfQSZ901bjSGG7bv1VHQOZUg"

    url = CONFIG.logic_app_url

    payload = json.dumps({
    "question": text
    })
    headers = {
    'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)

    return json.loads(response.text)[0]['answer']
